# generativepoetry

this is a repo for generative poem stuff
